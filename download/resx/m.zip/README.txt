MultilingualEditor.resx 文件夹是我改过的版本，中原本没有那个vs文件夹的，其实可以删掉。看情况。我转不回dll。【VS resgen.exe】
那个dll是原版文件。